var baseURL = "https://madebycanadians.ca/api/";
var imageBaseUrl ="https://madebycanadians.ca";

//var baseURL = "https://localhost:44384/" // local

$(document).ready(function() {

    $("#loginForm").submit(function(event) {
        event.preventDefault(); // Prevent page refresh

        var email = $("#email").val();
        var password = $("#password").val();

        $.ajax({
            url: baseURL+"api/User/login", // Update with your API URL
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({ email: email, password: password }),
            success: function(response) {
                localStorage.setItem("user", JSON.stringify(response)); // Store user data
                alert("Login successful! Redirecting...");
                window.location.href = "home.html"; // Redirect after login
            },
            error: function(xhr) {
                alert("Login failed: " + xhr.responseJSON.message);
            }
        });
    });

});

function GetCount(endpoint) {
    $.ajax({
        url: baseURL + "api/" + endpoint, // Constructing the endpoint URL dynamically
        type: "GET",
        dataType: "json",
        success: function(response) {
            var count = response.length; // Count the items in response
            $("#" + endpoint + "Count").text(count); // Dynamically update the corresponding count element
        },
        error: function() {
            console.error("Error fetching data from " + endpoint);
            $("#" + endpoint + "Count").text("0"); // Set to 0 in case of error
        }
    });
}

function UpdateUserData()
{
    debugger;
    var user = JSON.parse(localStorage.getItem("user"));
    if (user) {
        $(".userName").text(user.name);
    }   
}

function GetCategory()
{
    $.ajax({
        type: "GET",
        url: "Views/Category.html",
        data: "",
        cache: false,
        success: function(html) {
         document.getElementById("content").innerHTML = html;
         $('.NotView').hide();
         GetCategoryData();
        }
    });    
}

function GetCategoryData() {
    $.ajax({
        url: baseURL+"api/Category", // ✅ Ensure this matches your API endpoint
        type: "GET",
        dataType: "json",
        success: function(response) {
            var tbody = $("#CategoryTable tbody");
            tbody.empty(); // ✅ Clear previous data
            
            if (response.length === 0) {
                tbody.append("<tr><td colspan='3' class='text-center'>No Categories Found</td></tr>");
                return;
            }

            $.each(response, function(index, category) {
                var row = `<tr>
                    <td style="text-align:center;">${index + 1}</td>
                    <td contenteditable="true" onblur="updateData(${category.id}, 'Category', this)">${category.name}</td>
                    <td contenteditable="true" onblur="updateSerial(${category.id},'${category.name}','Category', this)">${category.serialNo}</td>
                    <td style="text-align:center;"><i class="fa fa-trash delete-icon" style="text-align:center; cursor: pointer; " onclick="DeleteCategory(${category.id})"></i></td>
                </tr>`;
                tbody.append(row);
            });
            scrollToTop();
            AddDataTable();
        },
        error: function(xhr, status, error) {
            console.error("Error loading categories:", error);
            alert("Failed to load categories: " + xhr.responseText);
        }
    });
}

function SaveCategory() {
    var categoryName = $("#name").val().trim(); // Get input value

    if (categoryName === "") {
        alert("Please enter a category name."); // Validation check
        return;
    }

    $.ajax({
        url: baseURL+"api/Category", // ✅ Adjust the URL based on your API route
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({ name: categoryName }), // Send JSON data
        success: function(response) {
            alert("Category saved successfully!");
            $("#name").val(""); // Clear input field after success
            GetCategoryData(); // Refresh table data
        },
        error: function(xhr, status, error) {
            console.error("Error:", xhr.status, xhr.responseText);
            alert("Failed to save category: " + (xhr.responseText || "Unknown error"));
        }
    });
}

function DeleteCategory(id) {
    if (confirm("Are you sure you want to delete this category?")) {
        fetch(baseURL+`api/Category/${id}`, { // Update with your API URL
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => {
            if (response.ok) {
                alert("Category deleted successfully!");
                GetCategoryData();
            } else {
                alert("Failed to delete category!");
            }
        })
        .catch(error => console.error("Error:", error));
    }
}

// Brand 

function GetBrand()
{
    $.ajax({
        type: "GET",
        url: "Views/Brand.html",
        data: "",
        cache: false,
        success: function(html) {
         document.getElementById("content").innerHTML = html;
         $('.NotView').hide();
         GetBrandData();
        }
    });    
}

function GetBrandData() {
    $.ajax({
        url: baseURL+"api/Brand", // ✅ Ensure this matches your API endpoint
        type: "GET",
        dataType: "json",
        success: function(response) {
            var tbody = $("#brandTable tbody");
            tbody.empty(); // ✅ Clear previous data
            
            if (response.length === 0) {
                tbody.append("<tr><td colspan='3' class='text-center'>No Brands Found</td></tr>");
                return;
            }

            $.each(response, function(index, brand) {
                var row = `<tr>
                    <td style="text-align:center;">${index + 1}</td>
                    <td contenteditable="true" onblur="updateData(${brand.id}, 'Brand', this)">${brand.name}</td>
                    <td style="text-align:center;"><i class="fa fa-trash delete-icon" style="text-align:center; cursor: pointer; " onclick="DeleteBrand(${brand.id})"></i></td>
                </tr>`;
                tbody.append(row);
            });
            scrollToTop();
            AddDataTable();
        },
        error: function(xhr, status, error) {
            console.error("Error loading categories:", error);
            alert("Failed to load categories: " + xhr.responseText);
        }
    });
}

function SaveBrand() {
    var brandName = $("#name").val().trim(); // Get input value

    if (brandName === "") {
        alert("Please enter a brand name."); // Validation check
        return;
    }

    $.ajax({
        url: baseURL+"api/Brand", // ✅ Adjust the URL based on your API route
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({ name: brandName }), // Send JSON data
        success: function(response) {
            alert("Brand saved successfully!");
            $("#name").val(""); // Clear input field after success
            GetBrandData(); // Refresh table data
        },
        error: function(xhr, status, error) {
            console.error("Error:", xhr.status, xhr.responseText);
            alert("Failed to save brand: " + (xhr.responseText || "Unknown error"));
        }
    });
}

function DeleteBrand(id) {
    if (confirm("Are you sure you want to delete this brand?")) {
        fetch(baseURL+`api/Brand/${id}`, { // Update with your API URL
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => {
            if (response.ok) {
                alert("Brand deleted successfully!");
                GetBrandData();
            } else {
                alert("Failed to delete brand!");
            }
        })
        .catch(error => console.error("Error:", error));
    }
}


// Company 

function GetCompany()
{
    $.ajax({
        type: "GET",
        url: "Views/Company.html",
        data: "",
        cache: false,
        success: function(html) {
         document.getElementById("content").innerHTML = html;
         $('.NotView').hide();
         GetCompanyData();
        }
    });    
}

function GetCompanyData() {
    $.ajax({
        url: baseURL+"api/Company", // ✅ Ensure this matches your API endpoint
        type: "GET",
        dataType: "json",
        success: function(response) {
            var tbody = $("#CompanyTable tbody");
            tbody.empty(); // ✅ Clear previous data
            
            if (response.length === 0) {
                tbody.append("<tr><td colspan='3' class='text-center'>No Companies Found</td></tr>");
                return;
            }

            $.each(response, function(index, company) {
                var row = `<tr>
                    <td style="text-align:center;">${index + 1}</td>
                    <td contenteditable="true" onblur="updateData(${company.id}, 'Company', this)">${company.name}</td>
                    <td style="text-align:center;"><i class="fa fa-trash delete-icon" style="text-align:center; cursor:Pointer;" onclick="DeleteCompany(${company.id})"></i></td>
                </tr>`;
                tbody.append(row);
            });
            scrollToTop();
        },
        error: function(xhr, status, error) {
            console.error("Error loading companies:", error);
            alert("Failed to load companies: " + xhr.responseText);
        }
    });
}

function SaveCompany() {
    var CompanyName = $("#name").val().trim(); // Get input value

    if (CompanyName === "") {
        alert("Please enter a Company name."); // Validation check
        return;
    }

    $.ajax({
        url: baseURL+"api/Company", // ✅ Adjust the URL based on your API route
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({ name: CompanyName }), // Send JSON data
        success: function(response) {
            alert("Company saved successfully!");
            $("#name").val(""); // Clear input field after success
            GetCompanyData(); // Refresh table data
        },
        error: function(xhr, status, error) {
            console.error("Error:", xhr.status, xhr.responseText);
            alert("Failed to save company: " + (xhr.responseText || "Unknown error"));
        }
    });
}

function DeleteCompany(id) {
    if (confirm("Are you sure you want to delete this Company?")) {
        fetch(baseURL+`api/Company/${id}`, { // Update with your API URL
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => {
            if (response.ok) {
                alert("Company deleted successfully!");
                GetCompanyData();
            } else {
                alert("Failed to delete Company!");
            }
        })
        .catch(error => console.error("Error:", error));
    }
}

// Province

function GetProvince()
{
    $.ajax({
        type: "GET",
        url: "Views/Province.html",
        data: "",
        cache: false,
        success: function(html) {
         document.getElementById("content").innerHTML = html;
         $('.NotView').hide();
         GetProvinceData();
        }
    });    
}

/*
function GetCompany()
{
    $.ajax({
        type: "POST",
        url: "Views/Company.html",
        data: "",
        cache: false,
        success: function(html) {
         document.getElementById("content").innerHTML = html;
         $('.NotView').hide();
         GetCompanyData();
        }
    });    
}
    */

function GetProvinceData() {
    $.ajax({
        url: baseURL+"api/Province", // ✅ Ensure this matches your API endpoint
        type: "GET",
        dataType: "json",
        success: function(response) {
            var tbody = $("#ProvinceTable tbody");
            tbody.empty(); // ✅ Clear previous data
            
            if (response.length === 0) {
                tbody.append("<tr><td colspan='3' class='text-center'>No Provinces Found</td></tr>");
                return;
            }

            $.each(response, function(index, Province) {
                var row = `<tr>
                    <td style="text-align:center;">${index + 1}</td>
                    <td contenteditable="true" onblur="updateData(${Province.id}, 'Province', this)">${Province.name}</td>
                    <td style="text-align:center;"><i class="fa fa-trash delete-icon" style="text-align:center; cursor:pointer;" onclick="DeleteProvince(${Province.id})"></i></td>
                </tr>`;
                tbody.append(row);
            });
            scrollToTop();
            AddDataTable();
        },
        error: function(xhr, status, error) {
            console.error("Error loading Provinces:", error);
            alert("Failed to load Province: " + xhr.responseText);
        }
    });
}

function SaveProvince() {
    var ProvinceName = $("#name").val().trim(); // Get input value

    if (ProvinceName === "") {
        alert("Please enter a Province name."); // Validation check
        return;
    }

    $.ajax({
        url: baseURL+"api/Province", // ✅ Adjust the URL based on your API route
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({ name: ProvinceName }), // Send JSON data
        success: function(response) {
            alert("Province saved successfully!");
            $("#name").val(""); // Clear input field after success
            GetProvinceData(); // Refresh table data
        },
        error: function(xhr, status, error) {
            console.error("Error:", xhr.status, xhr.responseText);
            alert("Failed to save Province: " + (xhr.responseText || "Unknown error"));
        }
    });
}

function DeleteProvince(id) {
    if (confirm("Are you sure you want to delete this Province?")) {
        fetch(baseURL+`api/Province/${id}`, { // Update with your API URL
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => {
            if (response.ok) {
                alert("Province deleted successfully!");
                GetProvinceData();
            } else {
                alert("Failed to delete Province!");
            }
        })
        .catch(error => console.error("Error:", error));
    }
}
// Vendor 

function GetVendor()
{
    $.ajax({
        type: "GET",
        url: "Views/Vendor.html",
        data: "",
        cache: false,
        success: function(html) {
         document.getElementById("content").innerHTML = html;
         $('.NotView').hide();
         GetVendorData();
        
        }
    });    
}

function GetVendorData() {
    $.ajax({
        url: baseURL+"api/Vendor", // ✅ Ensure this matches your API endpoint
        type: "GET",
        dataType: "json",
        success: function(response) {
            var tbody = $("#VendorTable tbody");
            tbody.empty(); // ✅ Clear previous data
            
            if (response.length === 0) {
                tbody.append("<tr><td colspan='3' class='text-center'>No Vendors Found</td></tr>");
                return;
            }

            $.each(response, function(index, Vendor) {
                var row = `<tr>
                    <td style="text-align:center;">${index + 1}</td>
                    <td contenteditable="true" onblur="updateData(${Vendor.id}, 'Vendor', this)">${Vendor.name}</td>
                    <td style="text-align:center;"><i class="fa fa-trash delete-icon" style="text-align:center; cursor:pointer;" onclick="DeleteVendor(${Vendor.id})"></i></td>
                </tr>`;
                tbody.append(row);
            });
            scrollToTop();
            AddDataTable();
        },
        error: function(xhr, status, error) {
            console.error("Error loading categories:", error);
            alert("Failed to load categories: " + xhr.responseText);
        }
    });
}

function SaveVendor() {
    var VendorName = $("#name").val().trim(); // Get input value

    if (VendorName === "") {
        alert("Please enter a Vendor name."); // Validation check
        return;
    }

    $.ajax({
        url: baseURL+"api/Vendor", // ✅ Adjust the URL based on your API route
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({ name: VendorName }), // Send JSON data
        success: function(response) {
            alert("Vendor saved successfully!");
            $("#name").val(""); // Clear input field after success
            GetVendorData(); // Refresh table data
        },
        error: function(xhr, status, error) {
            console.error("Error:", xhr.status, xhr.responseText);
            alert("Failed to save Vendor: " + (xhr.responseText || "Unknown error"));
        }
    });
}

function DeleteVendor(id) {
    if (confirm("Are you sure you want to delete this Vendor?")) {
        fetch(baseURL+`api/Vendor/${id}`, { // Update with your API URL
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => {
            if (response.ok) {
                alert("Vendor deleted successfully!");
                GetVendorData();
            } else {
                alert("Failed to delete Vendor!");
            }
        })
        .catch(error => console.error("Error:", error));
    }
}


// Product 

function GetProducts()
{
    $.ajax({
        type: "GET",
        url: "Views/Product.html",
        data: "",
        cache: false,
        success: function(html) {
         document.getElementById("content").innerHTML = html;
         $('.NotView').hide();
         GetProductData();
         LoadDropdowns();
        }
    });    
}

// ✅ Function to Fetch and Display Product List
function GetProductData() {
    $.ajax({
        url: baseURL+"api/Product", // Change API URL as needed
        type: "GET",
        success: function (data) {
            let tbody = $("#ProductTable tbody");
            tbody.empty();
            $.each(data, function (index, product) {
                tbody.append(`
                    <tr>
                        <td style="text-align:center;">${index + 1}</td>
                        <td>${product.name}</td>
                        <td>${product.shortDescription}</td>
                        <td>${product.longDescription}</td>
                        <td><img src="${imageBaseUrl+product.image}" width="50"></td>
                        <td>${product.price}</td>
                        <td>${product.stock}</td>
                        <td>${product.category ? product.category.name : 'N/A'}</td>
                        <td>${product.brand ? product.brand.name : 'N/A'}</td>
                        <td>${product.vendor ? product.vendor.name : 'N/A'}</td>
                        <td><a href="${product.productURL}" target="_blank">Link</a></td>
                        <td>${product.rting}</td>
                        <td>${product.province ? product.province.name : 'N/A'}</td>
                        <td style="text-align:center;"><i class="fa fa-edit edit-icon" style="text-align:center; cursor:pointer;" onclick="EditProduct(${product.id},this)"></i> &nbsp; <i class="fa fa-trash delete-icon" style="text-align:center; cursor:pointer;" onclick="DeleteProduct(${product.id})"></i></td>
                       
                     </tr>
                `);
            });
            scrollToTop();
            AddDataTable();
        },
        error: function (xhr) {
            console.error("Failed to load products:", xhr.responseText);
        }
    });
}

// ✅ Function to Upload Image
function UploadImage(callback) {
    let file = $("#productImage")[0].files[0];

    if (!file) {
        callback(null);
        return;
    }

    let formData = new FormData();
    formData.append("file", file);

    $.ajax({
        url: baseURL+"api/Product/UploadImage",
        type: "POST",
        data: formData,
        contentType: false,
        processData: false,
        success: function (imageUrl) {
            callback(imageUrl);
        },
        error: function (xhr) {
            console.error("Image upload failed:", xhr.responseText);
            callback(null);
        }
    });
}

// ✅ Function to Save a New Product
function SaveProduct() {
    UploadImage(function (imageUrl) {
        let productData = {
            name: $("#productName").val(),
            shortDescription: $("#productShortDesc").val(),
            longDescription: $("#productLongDesc").val(),
            image: imageUrl,
            price: parseFloat($("#productPrice").val()),
            stock: parseInt($("#productStock").val()),
            categoryId: parseInt($("#categoryDropdown").val()),
            brandId: parseInt($("#brandDropdown").val()),
            companyId: 3,
            provinceId: parseInt($("#provinceDropdown").val()),
            vendorId: parseInt($("#vendorDropdown").val()),
            productURL: $("#productURL").val(),
            rting: parseInt($("#ratingDropdown").val())
        };

        $.ajax({
            url: baseURL+"api/Product",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(productData),
            success: function () {
                alert("Product saved successfully!");
                GetProductData(); // Refresh product list
            },
            error: function (xhr) {
                console.error("Error saving product:", xhr.responseText);
            }
        });
    });
}

// Function to edit a product - loads data into the form
function EditProduct(productId, element) {
    // Show update button and hide save button
    $("button[onclick='SaveProduct()']").hide();
    $("button[onclick='UpdateProduct()']").show();
    
    // Store the product ID for update operation
    window.currentProductId = productId;
    
    // Get the product data from the table row
    let row = $(element).closest('tr');
    let cells = row.find('td');
    
    // Populate form fields with the data from the row
    $("#productName").val($(cells[1]).text());
    $("#productShortDesc").val($(cells[2]).text());
    $("#productLongDesc").val($(cells[3]).text());
    
    // For the image, we can't set the file input directly, but we can store the current image path
    let imgSrc = $(cells[4]).find('img').attr('src');
    window.currentProductImage = imgSrc.replace(imageBaseUrl, '');
    
    $("#productPrice").val(parseFloat($(cells[5]).text()));
    $("#productStock").val(parseInt($(cells[6]).text()));
    
    // Get category, brand, vendor, and province names from the table
    let categoryName = $(cells[7]).text();
    let brandName = $(cells[8]).text();
    let vendorName = $(cells[9]).text();
    let provinceName = $(cells[12]).text();
    
    // Set the dropdown values based on text (might need to be adjusted based on how your dropdowns are populated)
    setDropdownByText("#categoryDropdown", categoryName);
    setDropdownByText("#brandDropdown", brandName);
    setDropdownByText("#vendorDropdown", vendorName);
    setDropdownByText("#provinceDropdown", provinceName);
    
    // Get product URL from the link
    $("#productURL").val($(cells[10]).find('a').attr('href'));
    
    // Set rating
    $("#ratingDropdown").val($(cells[11]).text());
    
    // Scroll to the form
    $('html, body').animate({
        scrollTop: $("#add").offset().top
    }, 500);
}

// Helper function to set dropdown value based on text
function setDropdownByText(dropdownId, text) {
    if (text === 'N/A') return;
    
    $(dropdownId + " option").each(function() {
        if ($(this).text() === text) {
            $(dropdownId).val($(this).val());
            return false;
        }
    });
}

// Function to update an existing product
function UpdateProduct() {
    // Use the productId stored during EditProduct
    let productId = window.currentProductId;
    
    if (!productId) {
        alert("No product selected for update!");
        return;
    }
    
    // Check if a new image was selected
    UploadImage(function(imageUrl) {
        // If no new image was selected, use the existing one
        if (!imageUrl) {
            imageUrl = window.currentProductImage;
        }
        
        // Prepare the product data for update
        let productData = {
            id: productId,
            name: $("#productName").val(),
            shortDescription: $("#productShortDesc").val(),
            longDescription: $("#productLongDesc").val(),
            image: imageUrl,
            price: parseFloat($("#productPrice").val()),
            stock: parseInt($("#productStock").val()),
            categoryId: parseInt($("#categoryDropdown").val()),
            brandId: parseInt($("#brandDropdown").val()),
            companyId: 3,
            provinceId: parseInt($("#provinceDropdown").val()),
            vendorId: parseInt($("#vendorDropdown").val()),
            productURL: $("#productURL").val(),
            rting: parseInt($("#ratingDropdown").val())
        };
        
        // Send the update request
        $.ajax({
            url: baseURL + "api/Product/" + productId,
            type: "PUT",
            contentType: "application/json",
            data: JSON.stringify(productData),
            success: function() {
                alert("Product updated successfully!");
                
                // Reset form and buttons
                $("button[onclick='SaveProduct()']").show();
                $("button[onclick='UpdateProduct()']").hide();
                $("#productName, #productShortDesc, #productLongDesc, #productPrice, #productStock, #productURL").val('');
                $("#productImage").val('');
                $("#ratingDropdown").val('1');
                
                // Reset the stored product ID
                window.currentProductId = null;
                window.currentProductImage = null;
                
                // Refresh the product list
                GetProductData();
            },
            error: function(xhr) {
                console.error("Error updating product:", xhr.responseText);
                alert("Failed to update product. Please try again.");
            }
        });
    });
}

function DeleteProduct(id) {
    if (confirm("Are you sure you want to delete this Product?")) {
        fetch(baseURL+`api/Product/${id}`, { // Update with your API URL
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => {
            if (response.ok) {
                alert("Product deleted successfully!");
                GetProductData();
            } else {
                alert("Failed to delete Product!");
            }
        })
        .catch(error => console.error("Error:", error));
    }
}

// Product View 

function GetProductsView()
{
    $.ajax({
        type: "GET",
        url: "Views/ProductView.html",
        data: "",
        cache: false,
        success: function(html) {
         document.getElementById("content").innerHTML = html;
         $('.NotView').hide();
         GetProductViewData();
        }
    });    
}

// ✅ Function to Fetch and Display Product List
function GetProductViewData() {
    $.ajax({
        url: baseURL+"api/ProductView", // Change API URL as needed
        type: "GET",
        success: function (data) {
            let tbody = $("#productViewTable tbody");
            tbody.empty();
            $.each(data, function (index, productView) {
                tbody.append(`
                    <tr>
                        <td style="text-align:center;">${index + 1}</td>
                        <td>${productView.viewDate}</td>
                        <td>${productView.product.name}</td>
                        <td>${productView.product.shortDescription}</td>
                        <td>${productView.product.longDescription}</td>
                        <td><img src="${imageBaseUrl+productView.product.image}" width="50"></td>
                        <td>${productView.product.price}</td>
                        <td>${productView.product.stock}</td>
                        <td>${productView.product.category ? productView.product.category.name : 'N/A'}</td>
                        <td>${productView.product.vendor ? productView.product.vendor.name : 'N/A'}</td>
                        <td><a href="${productView.product.productURL}" target="_blank">Link</a></td>
                        <td>${productView.product.rting}</td>
                        <td>${productView.product.company ? productView.product.company.name : 'N/A'}</td>
                        <td>${productView.product.province ? productView.product.province.name : 'N/A'}</td>
                    </tr>
                `);
            });
            scrollToTop();
            AddDataTable();
        },
        error: function (xhr) {
            console.error("Failed to load products:", xhr.responseText);
        }
    });
}

// Contact 

function GetContacts()
{
    $.ajax({
        type: "GET",
        url: "Views/Contact.html",
        data: "",
        cache: false,
        success: function(html) {
         document.getElementById("content").innerHTML = html;
         $('.NotView').hide();
         GetContactData();
        }
    });    
}

function GetContactData()
{
    $.ajax({
        url: baseURL+"api/ContactForm/get",
        type: "GET",
        success: function (data) {
            let tableBody = $("#contactTable tbody");
            tableBody.empty(); // Clear previous data

            $.each(data, function (index, contact) {
                let row = `
                    <tr>
                        <td style='text-align:center;'>${index + 1}</td>
                        <td>${contact.firstName}</td>
                        <td>${contact.lastName}</td>
                        <td>${contact.phoneNumber}</td>
                        <td>${contact.email}</td>
                        <td>${contact.businessName || "-"}</td>
                        <td>${contact.websiteURL || "-"}</td>
                        <td>${contact.message || "-"}</td>
                        <td>${new Date(contact.createdAt).toLocaleString()}</td>
                    </tr>
                `;
                tableBody.append(row);
            });
            AddDataTable();
        },
        error: function (xhr, status, error) {
            console.error("Error fetching contacts:", error);
            alert("Failed to load contact data.");
        }
    });
}

// Common 

function updateData(id, apiName,e) {
    
    var name = $(e).text();
    // Define the API URL
    const apiUrl = baseURL+`api/${apiName}/${id}`;

    // Prepare the category data
    const Data = {
        id: id,
        name: name
    };

    try {
        // Send PUT request
        const response =  fetch(apiUrl, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(Data)
        });

        // Check response status
        if (response.ok) {
            console.log("Data updated successfully.");
        } else {
            console.error("Failed to update data:", response.status,  response.text());
        }
    } catch (error) {
        console.error("Error updating data:", error);
    }
}

function updateSerial(id,name, apiName,e) {
    
    var serialno = $(e).text();
    // Define the API URL
    const apiUrl = baseURL+`api/${apiName}/${id}`;

    // Prepare the category data
    const Data = {
        id: id,
        name: name,
        serialNo : serialno
    };

    try {
        // Send PUT request
        const response =  fetch(apiUrl, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(Data)
        });

        // Check response status
        if (response.ok) {
            console.log("Data updated successfully.");
        } else {
            console.error("Failed to update data:", response.status,  response.text());
        }
    } catch (error) {
        console.error("Error updating data:", error);
    }
}

function addNewData(apiName)
{
    var Name = prompt("Enter New "+apiName+" Name:");

    if (!Name || Name.trim() === "") {
        alert("Name cannot be empty.");
        return;
    }

    // Send AJAX request to save the category
    $.ajax({
        url: baseURL + "api/"+apiName,
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify({ name: Name.trim() }),
        success: function (response) {
            // Assume response contains { id: 1, name: "New Category" }
            var newOption = `<option value="${response.id}" selected>${response.name}</option>`;
            $("#"+apiName.toLowerCase()+"Dropdown").append(newOption); // Add to dropdown and select
        },
        error: function () {
            alert("Failed to add data. Try again.");
        }
    });

}

// ✅ Function to Populate Dropdowns for Category, Company, and Province
function PopulateDropdown(url, dropdownId, placeholder) {
    $.ajax({
        url: url,
        type: "GET",
        success: function (data) {
            let dropdown = $(dropdownId);
            dropdown.empty();
            dropdown.append(`<option value="">Select ${placeholder}</option>`);
            $.each(data, function (index, item) {
                dropdown.append(`<option value="${item.id}">${item.name}</option>`);
            });
        },
        error: function (xhr) {
            console.error(`Failed to load ${placeholder}:`, xhr.responseText);
        }
    });
}

// ✅ Function to Load Dropdown Data
function LoadDropdowns() {
    PopulateDropdown(baseURL+"api/Category", "#categoryDropdown", "Category");
    PopulateDropdown(baseURL+"api/Company", "#companyDropdown", "Company");
    PopulateDropdown(baseURL+"api/Province", "#provinceDropdown", "Province");
    PopulateDropdown(baseURL+"api/Vendor", "#vendorDropdown", "Vendor");
    PopulateDropdown(baseURL+"api/Brand", "#brandDropdown", "Brand");
}

function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function AddDataTable() {    
    if ($.fn.DataTable.isDataTable(".table")) {
        $(".table").DataTable().destroy();
    }

    $(".table").DataTable({
        "responsive": true,
        "autoWidth": false
    });
}


